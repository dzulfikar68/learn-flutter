class DataBMI {
  String tinggi;
  String berat;

  DataBMI({
    required this.tinggi,
    required this.berat,
  });
}
